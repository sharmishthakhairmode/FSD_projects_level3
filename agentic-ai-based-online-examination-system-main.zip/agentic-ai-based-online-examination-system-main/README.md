# agentic-ai-based-online-examination-system
An AI-based Online Examination System built using Flask that enables secure and automated exam conduction with user authentication and real-time evaluation.
