import os
def create_account():
    acc_no = input("Enter Account Number: ")
    name = input("Enter Account Holder Name: ")
    balance = "0"
    # Account details are stored in a file (bank.txt) [cite: 19]
    with open("bank.txt", "a") as file:
        file.write(f"{acc_no},{name},{balance}\n")
    print("Account created successfully\n")

def deposit():
    acc_no = input("Enter Account Number: ")
    
    if not os.path.exists("bank.txt"):
        print("Account not found\n")
        return

    updated_records = []
    found = False
    
    # Read file to check if account exists [cite: 41, 42]
    with open("bank.txt", "r") as file:
        for line in file:
            data = line.strip().split(",")
            if data[0] == acc_no:
                found = True
            updated_records.append(data)

    if not found:
        print("Account not found\n")
        return

    # Only ask for amount if account exists
    try:
        amount = int(input("Enter deposit amount: "))
    except ValueError:
        print("Invalid input.\n")
        return

    current_balance = 0
    # Overwrite file with updated balance [cite: 49, 51]
    with open("bank.txt", "w") as file:
        for data in updated_records:
            if data[0] == acc_no:
                current_balance = int(data[2]) + amount
                data[2] = str(current_balance)
            file.write(",".join(data) + "\n")
    
    print(f"Deposit successful. Current Balance: {current_balance}\n")

def withdraw():
    acc_no = input("Enter Account Number: ")
    
    if not os.path.exists("bank.txt"):
        print("Account not found\n")
        return

    updated_records = []
    found = False
    
    with open("bank.txt", "r") as file:
        for line in file:
            data = line.strip().split(",")
            if data[0] == acc_no:
                found = True
            updated_records.append(data)

    if not found:
        print("Account not found\n")
        return

    # Only ask for amount if account exists
    try:
        amount = int(input("Enter withdrawal amount: "))
    except ValueError:
        print("Invalid input.\n")
        return

    current_balance = 0
    success = False
    
    for data in updated_records:
        if data[0] == acc_no:
            # Check for sufficient balance [cite: 24, 67, 100]
            if int(data[2]) >= amount:
                current_balance = int(data[2]) - amount
                data[2] = str(current_balance)
                success = True
            else:
                print("Insufficient balance\n")
                return

    if success:
        with open("bank.txt", "w") as file:
            for data in updated_records:
                file.write(",".join(data) + "\n")
        print(f"Withdrawal successful. Remaining Balance: {current_balance}\n")

def display_balance():
    """Function to only display balance """
    acc_no = input("Enter Account Number: ")
    if not os.path.exists("bank.txt"):
        print("No records found.\n")
        return

    found = False
    with open("bank.txt", "r") as file:
        for line in file:
            data = line.strip().split(",")
            if data[0] == acc_no:
                print(f"\n--- Balance Inquiry ---")
                print(f"Account Holder: {data[1]}")
                print(f"Current Balance: {data[2]}\n")
                found = True
                break
    if not found:
        print("Account not found\n")

# Main Menu Logic [cite: 81-86]
while True:
    print("1. Create Account")
    print("2. Deposit")
    print("3. Withdraw")
    print("4. Check Balance")
    print("5. Exit")
    
    choice = input("Enter choice: ")
    if choice == "1":
        create_account()
    elif choice == "2":
        deposit()
    elif choice == "3":
        withdraw()
    elif choice == "4":
        display_balance()
    elif choice == "5":
        break
    else:
        print("Invalid choice\n")