# Online-Banking-System-Simulation
Online Banking System Simulation built using Python. This project demonstrates basic banking operations like account creation, deposit, withdrawal, and balance inquiry using file handling and menu-driven programming. Ideal for beginners to understand core Python concepts.
