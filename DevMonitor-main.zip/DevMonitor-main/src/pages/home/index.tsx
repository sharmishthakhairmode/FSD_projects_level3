import ItemPC from "@/components/serverItem"
import { fetchPCs } from "@/lib/db"
import useConnectionStore from "@/stores/connection"
import useUIStore from "@/stores/ui"
import { ServerPC } from "@/types/server"
import { AnimatePresence } from "framer-motion"
import { useEffect, useState } from "react"

function Home() {
    const { isOnline, checkOnline } = useConnectionStore()
    const { reloadKey, clearServerStatuses, setTotalServers } = useUIStore()
    const [serversList, setServersList] = useState<ServerPC[]>([])
    const [loading, setLoading] = useState(true)
    const [err, setErr] = useState<string | null>(null)

    useEffect(() => {
        checkOnline()
    }, [checkOnline])

    useEffect(() => {
        let cancelled = false
        setLoading(true)
        clearServerStatuses()

        const load = async () => {
            try {
                const pcs = await fetchPCs()
                if (!cancelled) {
                    setServersList(pcs)
                    setTotalServers(pcs.length)
                }
            } catch (e) {
                if (!cancelled)
                    setErr(e instanceof Error ? e.message : String(e))
            } finally {
                if (!cancelled) setLoading(false)
            }
        }

        load()
        return () => {
            cancelled = true
        }
    }, [reloadKey])

    return (
        <div className="flex flex-col gap-4">
            {/* System offline banner */}
            {!isOnline && (
                <div className="rounded-lg border border-destructive/20 bg-destructive/5 px-4 py-3 text-sm font-medium text-destructive">
                    Your device appears to be offline — ping results may be
                    inaccurate.
                </div>
            )}

            {/* Loading */}
            {loading && (
                <div className="flex flex-col gap-3">
                    {[...Array(3)].map((_, i) => (
                        <div
                            key={i}
                            className="h-14 animate-pulse rounded-lg border border-border bg-muted/50"
                        />
                    ))}
                </div>
            )}

            {/* Error */}
            {err && (
                <div className="rounded-lg border border-destructive/20 bg-destructive/5 px-4 py-3 text-sm font-medium text-destructive">
                    Failed to load servers: {err}
                </div>
            )}

            {/* Empty state */}
            {!loading && serversList.length === 0 && !err && (
                <div className="flex min-h-64 flex-col items-center justify-center rounded-lg border-2 border-dashed border-border">
                    <p className="text-sm font-medium text-foreground">
                        No servers yet
                    </p>
                    <p className="mt-1 text-sm text-muted-foreground">
                        Tap{" "}
                        <span className="font-medium text-foreground">
                            + Add Server
                        </span>{" "}
                        in the header to get started.
                    </p>
                </div>
            )}

            {/* Server list */}
            {!loading && serversList.length > 0 && (
                <div className="flex flex-col gap-3">
                    <AnimatePresence mode="popLayout">
                        {serversList.map((server, i) => (
                            <ItemPC
                                key={`${server.serverName}-${server.ip_domain}`}
                                server={server}
                                index={i}
                            />
                        ))}
                    </AnimatePresence>
                </div>
            )}
        </div>
    )
}

export default Home
