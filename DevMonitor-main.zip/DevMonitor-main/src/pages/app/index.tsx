import SideBar from "@/components/SideBar"
import ServerDetail from "@/components/ServerDetail"
import SettingsDrawer from "@/components/SettingsDrawer"
import useConnectionStore from "@/stores/connection"
import usePermissionStore from "@/stores/permissions"
import useUIStore from "@/stores/ui"
import {
    isPermissionGranted,
    requestPermission
} from "@tauri-apps/plugin-notification"
import { Moon, Plus, RefreshCw, Sun, Settings } from "lucide-react"
import { useEffect } from "react"
import { Route, Routes } from "react-router-dom"
import Home from "../home"

function App() {
    const { setMessagePermission } = usePermissionStore()
    const { checkOnline } = useConnectionStore()
    const {
        drawerOpen,
        openAddDrawer,
        closeDrawer,
        isDark,
        toggleTheme,
        triggerPing,
        serverStatuses,
        totalServers,
        openSettings
    } = useUIStore()

    useEffect(() => {
        ;(async () => {
            let granted = await isPermissionGranted()
            if (!granted) {
                granted = (await requestPermission()) === "granted"
            }
            setMessagePermission(granted)
        })()
    }, [setMessagePermission])

    useEffect(() => {
        checkOnline()
        const interval = setInterval(checkOnline, 30_000)
        return () => clearInterval(interval)
    }, [checkOnline])

    const onlineCount = Object.values(serverStatuses).filter(
        (v) => v === true
    ).length
    const hasStatuses = Object.keys(serverStatuses).length > 0

    return (
        <div className="flex flex-col h-screen bg-background text-foreground">
            {/* Header */}
            <header
                className="sticky top-0 z-40 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/60"
                style={{ paddingTop: "max(env(safe-area-inset-top), 0px)" }}
            >
                <div className="flex items-center gap-3 px-4 py-3 sm:px-6">
                    {/* Logo + title */}
                    <div className="flex items-center gap-2.5 min-w-0">
                        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-primary">
                            <span className="text-[10px] font-bold text-primary-foreground leading-none">
                                DM
                            </span>
                        </div>
                        <span className="text-base font-semibold truncate">
                            DevMonitor
                        </span>
                    </div>

                    {/* Live status count */}
                    {totalServers > 0 && (
                        <div className="hidden sm:flex items-center gap-1.5 rounded-full border border-border bg-background px-2.5 py-1 text-xs font-medium">
                            <span
                                className={`h-1.5 w-1.5 rounded-full ${
                                    hasStatuses && onlineCount === totalServers
                                        ? "bg-green-500"
                                        : hasStatuses && onlineCount === 0
                                          ? "bg-destructive"
                                          : "bg-yellow-500"
                                }`}
                            />
                            <span className="text-foreground">
                                {hasStatuses ? onlineCount : "—"}
                                <span className="text-muted-foreground">
                                    /{totalServers}
                                </span>
                            </span>
                        </div>
                    )}

                    <div className="ml-auto flex items-center gap-1.5">
                        {/* Refresh */}
                        <button
                            onClick={triggerPing}
                            className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                            title="Re-ping all servers"
                            aria-label="Refresh all pings"
                        >
                            <RefreshCw className="h-4 w-4" />
                        </button>

                        {/* Settings */}
                        <button
                            onClick={openSettings}
                            className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                            title="Email alert settings"
                            aria-label="Open email settings"
                        >
                            <Settings className="h-4 w-4" />
                        </button>

                        {/* Dark mode toggle */}
                        <button
                            onClick={toggleTheme}
                            className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                            title={isDark ? "Switch to light mode" : "Switch to dark mode"}
                            aria-label="Toggle theme"
                        >
                            {isDark ? (
                                <Sun className="h-4 w-4" />
                            ) : (
                                <Moon className="h-4 w-4" />
                            )}
                        </button>

                        {/* Add server */}
                        <button
                            onClick={openAddDrawer}
                            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground transition hover:bg-primary/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                        >
                            <Plus className="h-4 w-4" />
                            <span className="hidden sm:inline">Add Server</span>
                        </button>
                    </div>
                </div>
            </header>

            {/* Main */}
            <main
                className="flex-1 overflow-y-auto"
                style={{
                    paddingBottom: "max(env(safe-area-inset-bottom), 0px)"
                }}
            >
                <div className="mx-auto w-full max-w-2xl px-4 py-6 sm:px-6">
                    <SideBar open={drawerOpen} setOpen={closeDrawer} />
                    <ServerDetail />
                    <SettingsDrawer />
                    <Routes>
                        <Route path="/" element={<Home />} />
                    </Routes>
                </div>
            </main>
        </div>
    )
}

export default App
