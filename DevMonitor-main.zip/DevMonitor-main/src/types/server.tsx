export type ServerCall = {
    domain: string
    ip: string
    protocol: string
    port: number
}

export type ServerPC = {
    serverName: string
    ip_domain: string
    protocol: string
    port: number
    timeMilliseconds: number
    notify: number
    alert_rtt_threshold?: number
    alert_after_failures?: number
    webhook_url?: string
}

export type PingResult = {
    domain: string
    success: boolean
    rtt: number
}
