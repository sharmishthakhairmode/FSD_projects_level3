export const CHECK_INTERVALS = [
  { label: "Every 30 seconds", value: "_30s", ms: 10_000 },
  { label: "Every 5 minutes",  value: "five",    ms: 300_000 },
  { label: "Every 15 minutes", value: "fifteen", ms: 900_000 },
  { label: "Every 30 minutes", value: "thirty",  ms: 1_800_000 },
  { label: "Every hour",       value: "hour",    ms: 3_600_000 },
] as const
