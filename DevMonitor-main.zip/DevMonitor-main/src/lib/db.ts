import { ServerPC } from "@/types/server"
import DB from "@tauri-apps/plugin-sql"

let dbPromise: Promise<DB> | null = null

export function getDB(): Promise<DB> {
    if (!dbPromise) {
        dbPromise = DB.load("sqlite:data.db")
    }
    return dbPromise
}

export async function deleteServer(serverName: string): Promise<void> {
    const db = await getDB()
    await db.execute(`DELETE FROM ping_history WHERE serverName = ?`, [serverName])
    await db.execute(`DELETE FROM servers WHERE serverName = ?`, [serverName])
}

export async function addServer(server: ServerPC): Promise<string> {
    const db = await getDB()
    await db.execute(
        `INSERT INTO servers (servername, ip_domain, protocol, port, timeMilliseconds, notify, alert_rtt_threshold, alert_after_failures, webhook_url)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
            server.serverName,
            server.ip_domain,
            server.protocol,
            server.port,
            server.timeMilliseconds,
            server.notify,
            server.alert_rtt_threshold ?? 0,
            server.alert_after_failures ?? 1,
            server.webhook_url ?? ""
        ]
    )
    return server.serverName
}

export async function updateServer(server: ServerPC): Promise<void> {
    const db = await getDB()
    await db.execute(
        `UPDATE servers SET ip_domain = ?, protocol = ?, port = ?, timeMilliseconds = ?, notify = ?, alert_rtt_threshold = ?, alert_after_failures = ?, webhook_url = ?
         WHERE serverName = ?`,
        [
            server.ip_domain,
            server.protocol,
            server.port,
            server.timeMilliseconds,
            server.notify,
            server.alert_rtt_threshold ?? 0,
            server.alert_after_failures ?? 1,
            server.webhook_url ?? "",
            server.serverName
        ]
    )
}

export async function fetchPCs(): Promise<ServerPC[]> {
    const db = await getDB()
    const rows = await db.select<ServerPC[]>(
        `SELECT serverName, ip_domain, protocol, port, timeMilliseconds, notify, alert_rtt_threshold, alert_after_failures, webhook_url
         FROM servers
         ORDER BY serverName`
    )
    return rows
}

export async function recordPing(
    serverName: string,
    success: boolean,
    rtt: number | null
): Promise<void> {
    const db = await getDB()
    const now = Date.now()

    await db.execute(
        `INSERT INTO ping_history (serverName, timestamp, success, rtt)
         VALUES (?, ?, ?, ?)`,
        [serverName, now, success ? 1 : 0, rtt ?? null]
    )

    const thirtyDaysAgo = now - 30 * 24 * 60 * 60 * 1000
    await db.execute(
        `DELETE FROM ping_history WHERE serverName = ? AND timestamp < ?`,
        [serverName, thirtyDaysAgo]
    )
}

export async function fetchUptimePercent(
    serverName: string,
    sinceMs: number
): Promise<number | null> {
    const db = await getDB()
    const rows = await db.select<{ total: number; successes: number }[]>(
        `SELECT
           COUNT(*)                          AS total,
           SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END) AS successes
         FROM ping_history
         WHERE serverName = ? AND timestamp >= ?`,
        [serverName, sinceMs]
    )
    const row = rows[0]
    if (!row || row.total === 0) return null
    return Math.round((row.successes / row.total) * 100)
}

// TICK-S02: Fetch RTT statistics
export type RttStats = { avg: number; min: number; max: number }
export async function fetchRttStats(
    serverName: string,
    sinceMs: number
): Promise<RttStats | null> {
    const db = await getDB()
    const rows = await db.select<{ avg: number; min: number; max: number }[]>(
        `SELECT AVG(rtt) AS avg, MIN(rtt) AS min, MAX(rtt) AS max
         FROM ping_history
         WHERE serverName = ? AND timestamp >= ? AND success = 1`,
        [serverName, sinceMs]
    )
    const row = rows[0]
    if (!row || row.avg === null) return null
    return {
        avg: Math.round(row.avg),
        min: row.min,
        max: row.max
    }
}

// TICK-S03: Fetch incident count
export async function fetchIncidentCount(
    serverName: string,
    sinceMs: number
): Promise<number> {
    const db = await getDB()
    const rows = await db.select<{ count: number }[]>(
        `SELECT COUNT(*) AS count FROM ping_history p
         WHERE p.serverName = ? AND p.timestamp >= ?
           AND p.success = 0
           AND NOT EXISTS (
             SELECT 1 FROM ping_history p2
             WHERE p2.serverName = p.serverName
               AND p2.timestamp < p.timestamp
               AND p2.success = 0
               AND NOT EXISTS (
                 SELECT 1 FROM ping_history p3
                 WHERE p3.serverName = p.serverName
                   AND p3.timestamp > p2.timestamp
                   AND p3.timestamp < p.timestamp
                   AND p3.success = 1
               )
           )`,
        [serverName, sinceMs]
    )
    return rows[0]?.count ?? 0
}

// TICK-S04: Fetch total downtime in milliseconds
export async function fetchTotalDowntime(
    serverName: string,
    sinceMs: number
): Promise<number> {
    const db = await getDB()
    const rows = await db.select<{ downtime_ms: number }[]>(
        `SELECT COUNT(*) * s.timeMilliseconds AS downtime_ms
         FROM ping_history p
         JOIN servers s ON p.serverName = s.serverName
         WHERE p.serverName = ? AND p.timestamp >= ? AND p.success = 0`,
        [serverName, sinceMs]
    )
    return rows[0]?.downtime_ms ?? 0
}

// TICK-S05: Fetch last time server was seen online
export async function fetchLastSeenOnline(serverName: string): Promise<number | null> {
    const db = await getDB()
    const rows = await db.select<{ timestamp: number }[]>(
        `SELECT MAX(timestamp) AS timestamp FROM ping_history
         WHERE serverName = ? AND success = 1`,
        [serverName]
    )
    return rows[0]?.timestamp ?? null
}

// TICK-G02: Fetch RTT history for charting
export async function fetchRttHistory(
    serverName: string,
    sinceMs: number
): Promise<{ timestamp: number; rtt: number }[]> {
    const db = await getDB()
    return db.select<{ timestamp: number; rtt: number }[]>(
        `SELECT timestamp, rtt
         FROM ping_history
         WHERE serverName = ? AND timestamp >= ? AND success = 1
         ORDER BY timestamp ASC`,
        [serverName, sinceMs]
    )
}

// TICK-G05: Fetch RTT sparkline
export async function fetchRttSparkline(
    serverName: string,
    limit: number
): Promise<number[]> {
    const db = await getDB()
    const rows = await db.select<{ rtt: number }[]>(
        `SELECT rtt FROM ping_history
         WHERE serverName = ? AND success = 1
         ORDER BY timestamp DESC
         LIMIT ?`,
        [serverName, limit]
    )
    return rows.map((r) => r.rtt).reverse()
}

// TICK-G04: Fetch daily uptime percentages
export async function fetchDailyUptime(
    serverName: string,
    sinceMs: number
): Promise<{ date: string; uptime: number }[]> {
    const db = await getDB()
    const rows = await db.select<{ day: string; total: number; successes: number }[]>(
        `SELECT
           strftime('%Y-%m-%d', timestamp / 1000, 'unixepoch') AS day,
           COUNT(*)                                              AS total,
           SUM(CASE WHEN success = 1 THEN 1 ELSE 0 END)        AS successes
         FROM ping_history
         WHERE serverName = ? AND timestamp >= ?
         GROUP BY day
         ORDER BY day ASC`,
        [serverName, sinceMs]
    )
    return rows.map((r) => ({
        date: r.day,
        uptime: r.total === 0 ? 0 : Math.round((r.successes / r.total) * 100),
    }))
}

// TICK-A04: SMTP settings functions
export type SmtpSettings = {
    host: string
    port: number
    user: string
    password: string
    fromAddress: string
    toAddress: string
}

export async function fetchSmtpSettings(): Promise<SmtpSettings | null> {
    const db = await getDB()
    const rows = await db.select<{ key: string; value: string }[]>(
        `SELECT key, value FROM settings WHERE key LIKE 'smtp_%'`
    )
    if (rows.length === 0) return null
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]))
    if (!map["smtp_host"]) return null
    return {
        host: map["smtp_host"] ?? "",
        port: Number(map["smtp_port"] ?? 587),
        user: map["smtp_user"] ?? "",
        password: map["smtp_password"] ?? "",
        fromAddress: map["smtp_from"] ?? "",
        toAddress: map["smtp_to"] ?? "",
    }
}

export async function saveSmtpSettings(s: SmtpSettings): Promise<void> {
    const db = await getDB()
    const entries: [string, string][] = [
        ["smtp_host", s.host],
        ["smtp_port", String(s.port)],
        ["smtp_user", s.user],
        ["smtp_password", s.password],
        ["smtp_from", s.fromAddress],
        ["smtp_to", s.toAddress],
    ]
    for (const [key, value] of entries) {
        await db.execute(
            `INSERT INTO settings (key, value) VALUES (?, ?)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
            [key, value]
        )
    }
}
