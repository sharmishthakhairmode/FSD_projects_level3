import {
    Dialog,
    DialogBackdrop,
    DialogPanel,
    Transition,
    TransitionChild,
} from "@headlessui/react"
import { XMarkIcon } from "@heroicons/react/24/outline"
import useUIStore from "@/stores/ui"
import { Fragment, useEffect, useState } from "react"
import {
    LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
} from "recharts"
import { fetchRttHistory, fetchRttStats, RttStats, fetchIncidentCount, fetchTotalDowntime, fetchDailyUptime } from "@/lib/db"

const RANGES = [
    { label: "1h",  ms: 60 * 60 * 1000 },
    { label: "6h",  ms: 6 * 60 * 60 * 1000 },
    { label: "24h", ms: 24 * 60 * 60 * 1000 },
    { label: "7d",  ms: 7 * 24 * 60 * 60 * 1000 },
    { label: "30d", ms: 30 * 24 * 60 * 60 * 1000 },
] as const

type RangeLabel = (typeof RANGES)[number]["label"]

export default function ServerDetail() {
    const { detailServer, closeDetailDrawer } = useUIStore()
    const open = detailServer !== null
    const [range, setRange] = useState<RangeLabel>("24h")
    const [rttData, setRttData] = useState<{ timestamp: number; rtt: number }[]>([])
    const [rttStats, setRttStats] = useState<RttStats | null>(null)
    const [incidentCount, setIncidentCount] = useState<number>(0)
    const [totalDowntime, setTotalDowntime] = useState<number>(0)
    const [dailyUptime, setDailyUptime] = useState<{ date: string; uptime: number }[]>([])

    const sinceMs = Date.now() - (RANGES.find((r) => r.label === range)?.ms ?? 24 * 60 * 60 * 1000)

    // Fetch RTT history (TICK-G02)
    useEffect(() => {
        if (!detailServer) return
        fetchRttHistory(detailServer.serverName, sinceMs)
            .then(setRttData)
            .catch(console.error)
    }, [detailServer?.serverName, sinceMs])

    // Fetch RTT stats (TICK-S02)
    useEffect(() => {
        if (!detailServer) return
        fetchRttStats(detailServer.serverName, sinceMs)
            .then(setRttStats)
            .catch(console.error)
    }, [detailServer?.serverName, sinceMs])

    // Fetch incident count (TICK-S03)
    useEffect(() => {
        if (!detailServer) return
        fetchIncidentCount(detailServer.serverName, sinceMs)
            .then(setIncidentCount)
            .catch(console.error)
    }, [detailServer?.serverName, sinceMs])

    // Fetch total downtime (TICK-S04)
    useEffect(() => {
        if (!detailServer) return
        fetchTotalDowntime(detailServer.serverName, sinceMs)
            .then(setTotalDowntime)
            .catch(console.error)
    }, [detailServer?.serverName, sinceMs])

    // Fetch daily uptime (TICK-G04)
    useEffect(() => {
        if (!detailServer) return
        fetchDailyUptime(detailServer.serverName, sinceMs)
            .then(setDailyUptime)
            .catch(console.error)
    }, [detailServer?.serverName, sinceMs])

    const formatDowntime = (ms: number): string => {
        if (ms === 0) return "0 min"
        const totalSeconds = Math.floor(ms / 1000)
        const hours = Math.floor(totalSeconds / 3600)
        const minutes = Math.floor((totalSeconds % 3600) / 60)
        if (hours === 0) return `${minutes} min`
        if (minutes === 0) return `${hours} h`
        return `${hours} h ${minutes} min`
    }

    return (
        <Transition show={open} as={Fragment}>
            <Dialog as="div" className="relative z-50" onClose={closeDetailDrawer}>
                <TransitionChild
                    as={Fragment}
                    enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100"
                    leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0"
                >
                    <DialogBackdrop className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                </TransitionChild>

                <div className="fixed inset-0 overflow-hidden">
                    <div className="absolute inset-0 overflow-hidden">
                        <div className="fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16">
                            <TransitionChild
                                as={Fragment}
                                enter="transform transition ease-in-out duration-300"
                                enterFrom="translate-x-full" enterTo="translate-x-0"
                                leave="transform transition ease-in-out duration-300"
                                leaveFrom="translate-x-0" leaveTo="translate-x-full"
                            >
                                <DialogPanel className="pointer-events-auto w-screen max-w-lg">
                                    <div className="flex h-full flex-col bg-card shadow-xl">
                                        {/* Header */}
                                        <div className="flex items-center justify-between border-b border-border px-6 py-4">
                                            <div>
                                                <h2 className="text-lg font-semibold text-foreground">
                                                    {detailServer?.serverName}
                                                </h2>
                                                <p className="text-sm text-muted-foreground">
                                                    {detailServer?.ip_domain}
                                                </p>
                                            </div>
                                            <button
                                                onClick={closeDetailDrawer}
                                                className="rounded-md p-1 text-muted-foreground hover:text-foreground"
                                            >
                                                <XMarkIcon className="h-5 w-5" />
                                            </button>
                                        </div>

                                        {/* Content */}
                                        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-6">
                                            {/* Stats Grid - TICK-S02, S03, S04 */}
                                            <div>
                                                <h3 className="mb-3 text-sm font-medium text-foreground">Statistics</h3>
                                                <div className="grid grid-cols-2 gap-3">
                                                    {rttStats && (
                                                        <>
                                                            <div className="rounded-lg border border-border p-3">
                                                                <p className="text-xs text-muted-foreground">Avg RTT</p>
                                                                <p className="mt-1 text-base font-semibold text-foreground">{rttStats.avg}ms</p>
                                                            </div>
                                                            <div className="rounded-lg border border-border p-3">
                                                                <p className="text-xs text-muted-foreground">Min/Max</p>
                                                                <p className="mt-1 text-base font-semibold text-foreground">{rttStats.min}ms / {rttStats.max}ms</p>
                                                            </div>
                                                        </>
                                                    )}
                                                    <div className="rounded-lg border border-border p-3">
                                                        <p className="text-xs text-muted-foreground">Incidents</p>
                                                        <p className="mt-1 text-base font-semibold text-foreground">{incidentCount}</p>
                                                    </div>
                                                    <div className="rounded-lg border border-border p-3">
                                                        <p className="text-xs text-muted-foreground">Total Downtime</p>
                                                        <p className="mt-1 text-base font-semibold text-foreground">{formatDowntime(totalDowntime)}</p>
                                                    </div>
                                                </div>
                                            </div>

                                            {/* Time range selector - TICK-G03 */}
                                            <div className="flex gap-1 rounded-lg border border-border p-1">
                                                {RANGES.map((r) => (
                                                    <button
                                                        key={r.label}
                                                        onClick={() => setRange(r.label)}
                                                        className={`flex-1 rounded px-2 py-1 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50 ${
                                                            range === r.label
                                                                ? "bg-primary text-primary-foreground"
                                                                : "text-muted-foreground hover:bg-muted hover:text-foreground"
                                                        }`}
                                                    >
                                                        {r.label}
                                                    </button>
                                                ))}
                                            </div>

                                            {/* Response time chart - TICK-G02 */}
                                            <div>
                                                <h3 className="mb-3 text-sm font-medium text-foreground">Response Time</h3>
                                                {rttData.length === 0 ? (
                                                    <p className="text-sm text-muted-foreground">No data yet.</p>
                                                ) : (
                                                    <ResponsiveContainer width="100%" height={200}>
                                                        <LineChart data={rttData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
                                                            <XAxis
                                                                dataKey="timestamp"
                                                                tickFormatter={(v) =>
                                                                    new Date(v).toLocaleTimeString([], {
                                                                        hour: "2-digit",
                                                                        minute: "2-digit",
                                                                    })
                                                                }
                                                                tick={{ fontSize: 11 }}
                                                                minTickGap={60}
                                                            />
                                                            <YAxis unit="ms" tick={{ fontSize: 11 }} width={48} />
                                                            <Tooltip
                                                                labelFormatter={(v) => new Date(v as number).toLocaleString()}
                                                                formatter={(v: unknown) => [`${v}ms`, "RTT"]}
                                                                contentStyle={{
                                                                    fontSize: 12,
                                                                    borderRadius: "6px",
                                                                }}
                                                            />
                                                            <Line
                                                                type="monotone"
                                                                dataKey="rtt"
                                                                stroke="var(--color-primary)"
                                                                strokeWidth={1.5}
                                                                dot={false}
                                                                isAnimationActive={false}
                                                            />
                                                        </LineChart>
                                                    </ResponsiveContainer>
                                                )}
                                            </div>

                                            {/* Daily uptime chart - TICK-G04 */}
                                            <div>
                                                <h3 className="mb-3 text-sm font-medium text-foreground">Daily Uptime</h3>
                                                {dailyUptime.length === 0 ? (
                                                    <p className="text-sm text-muted-foreground">No data yet.</p>
                                                ) : (
                                                    <ResponsiveContainer width="100%" height={140}>
                                                        <LineChart data={dailyUptime} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
                                                            <XAxis
                                                                dataKey="date"
                                                                tick={{ fontSize: 11 }}
                                                                tickFormatter={(v: string) => v.slice(5)}
                                                            />
                                                            <YAxis
                                                                domain={[0, 100]}
                                                                unit="%"
                                                                tick={{ fontSize: 11 }}
                                                                width={40}
                                                            />
                                                            <Tooltip
                                                                formatter={(v: unknown) => [`${v}%`, "Uptime"]}
                                                                contentStyle={{ fontSize: 12, borderRadius: "6px" }}
                                                            />
                                                            <Line
                                                                type="monotone"
                                                                dataKey="uptime"
                                                                stroke="var(--color-primary)"
                                                                strokeWidth={1.5}
                                                                dot={false}
                                                                isAnimationActive={false}
                                                            />
                                                        </LineChart>
                                                    </ResponsiveContainer>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                </DialogPanel>
                            </TransitionChild>
                        </div>
                    </div>
                </div>
            </Dialog>
        </Transition>
    )
}
