import {
    Dialog,
    DialogBackdrop,
    DialogPanel,
    Transition,
    TransitionChild,
} from "@headlessui/react"
import { XMarkIcon } from "@heroicons/react/24/outline"
import { Fragment, useEffect, useState } from "react"
import useUIStore from "@/stores/ui"
import { fetchSmtpSettings, saveSmtpSettings, SmtpSettings } from "@/lib/db"
import { invoke } from "@tauri-apps/api/core"

const EMPTY: SmtpSettings = {
    host: "",
    port: 587,
    user: "",
    password: "",
    fromAddress: "",
    toAddress: "",
}

export default function SettingsDrawer() {
    const { settingsOpen, closeSettings } = useUIStore()
    const [form, setForm] = useState<SmtpSettings>(EMPTY)
    const [status, setStatus] = useState<"idle" | "saving" | "saved" | "error">("idle")

    // Pre-fill on open
    useEffect(() => {
        if (!settingsOpen) return
        fetchSmtpSettings()
            .then((s) => { if (s) setForm(s) })
            .catch(console.error)
    }, [settingsOpen])

    const handleSave = async () => {
        setStatus("saving")
        try {
            await saveSmtpSettings(form)
            setStatus("saved")
            setTimeout(() => setStatus("idle"), 3000)
        } catch {
            setStatus("error")
            setTimeout(() => setStatus("idle"), 3000)
        }
    }

    const handleTestEmail = async () => {
        setStatus("saving")
        try {
            await invoke("send_alert_email", {
                host: form.host,
                port: form.port,
                user: form.user,
                password: form.password,
                from: form.fromAddress,
                to: form.toAddress,
                subject: "[DevMonitor] Test email",
                body: "If you received this, your email alerts are working.",
            })
            setStatus("saved")
            setTimeout(() => setStatus("idle"), 3000)
        } catch (err) {
            console.error("Test email failed:", err)
            setStatus("error")
            setTimeout(() => setStatus("idle"), 3000)
        }
    }

    const set = (field: keyof SmtpSettings) =>
        (e: React.ChangeEvent<HTMLInputElement>) =>
            setForm((prev) => ({ ...prev, [field]: field === "port" ? Number(e.target.value) : e.target.value }))

    return (
        <Transition show={settingsOpen} as={Fragment}>
            <Dialog as="div" className="relative z-50" onClose={closeSettings}>
                <TransitionChild
                    as={Fragment}
                    enter="ease-out duration-300" enterFrom="opacity-0" enterTo="opacity-100"
                    leave="ease-in duration-200" leaveFrom="opacity-100" leaveTo="opacity-0"
                >
                    <DialogBackdrop className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                </TransitionChild>

                <div className="fixed inset-0 overflow-hidden">
                    <div className="absolute inset-0 overflow-hidden">
                        <div className="fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16">
                            <TransitionChild
                                as={Fragment}
                                enter="transform transition ease-in-out duration-300"
                                enterFrom="translate-x-full" enterTo="translate-x-0"
                                leave="transform transition ease-in-out duration-300"
                                leaveFrom="translate-x-0" leaveTo="translate-x-full"
                            >
                                <DialogPanel className="pointer-events-auto w-screen max-w-md">
                                    <div className="flex h-full flex-col bg-card shadow-xl">
                                        {/* Header */}
                                        <div className="flex items-center justify-between border-b border-border px-6 py-4">
                                            <h2 className="text-lg font-semibold text-foreground">
                                                Email Alert Settings
                                            </h2>
                                            <button
                                                onClick={closeSettings}
                                                className="rounded-md p-1 text-muted-foreground hover:text-foreground"
                                            >
                                                <XMarkIcon className="h-5 w-5" />
                                            </button>
                                        </div>

                                        {/* Form */}
                                        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-4">
                                            {(
                                                [
                                                    { label: "SMTP Host", field: "host", type: "text", placeholder: "smtp.example.com" },
                                                    { label: "SMTP Port", field: "port", type: "number", placeholder: "587" },
                                                    { label: "Username", field: "user", type: "text", placeholder: "you@example.com" },
                                                    { label: "Password", field: "password", type: "password", placeholder: "••••••••" },
                                                    { label: "From Address", field: "fromAddress", type: "email", placeholder: "alerts@example.com" },
                                                    { label: "To Address", field: "toAddress", type: "email", placeholder: "you@example.com" },
                                                ] as const
                                            ).map(({ label, field, type, placeholder }) => (
                                                <div key={field}>
                                                    <label className="mb-1.5 block text-sm font-medium text-foreground">
                                                        {label}
                                                    </label>
                                                    <input
                                                        type={type}
                                                        value={form[field]}
                                                        onChange={set(field)}
                                                        placeholder={placeholder}
                                                        className="w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/50"
                                                    />
                                                </div>
                                            ))}
                                        </div>

                                        {/* Footer */}
                                        <div className="border-t border-border px-6 py-4 space-y-3">
                                            {status === "saved" && (
                                                <p className="text-sm text-green-600 dark:text-green-400">
                                                    Settings saved.
                                                </p>
                                            )}
                                            {status === "error" && (
                                                <p className="text-sm text-destructive">
                                                    Failed to save. Check the console.
                                                </p>
                                            )}
                                            <div className="space-y-2">
                                                <button
                                                    onClick={handleSave}
                                                    disabled={status === "saving"}
                                                    className="w-full rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition hover:bg-primary/90 disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                                                >
                                                    {status === "saving" ? "Saving…" : "Save Settings"}
                                                </button>
                                                <button
                                                    onClick={handleTestEmail}
                                                    disabled={status === "saving"}
                                                    className="w-full rounded-md border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition hover:bg-muted disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                                                >
                                                    Send Test Email
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </DialogPanel>
                            </TransitionChild>
                        </div>
                    </div>
                </div>
            </Dialog>
        </Transition>
    )
}
