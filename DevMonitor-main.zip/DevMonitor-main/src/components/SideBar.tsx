import {
    Dialog,
    DialogBackdrop,
    DialogPanel,
    Transition,
    TransitionChild
} from "@headlessui/react"
import { XMarkIcon } from "@heroicons/react/24/outline"
import useUIStore from "@/stores/ui"
import { Fragment } from "react"
import AddPCForm from "./form"

interface SettingsDrawerProps {
    open: boolean
    setOpen: (value: boolean) => void
}

export default function SettingsDrawer({ open, setOpen }: SettingsDrawerProps) {
    const { editServer } = useUIStore()

    return (
        <Transition show={open} as={Fragment}>
            <Dialog as="div" className="relative z-50" onClose={setOpen}>
                <TransitionChild
                    as={Fragment}
                    enter="ease-out duration-300"
                    enterFrom="opacity-0"
                    enterTo="opacity-100"
                    leave="ease-in duration-200"
                    leaveFrom="opacity-100"
                    leaveTo="opacity-0"
                >
                    <DialogBackdrop className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                </TransitionChild>

                <div className="fixed inset-0 overflow-hidden">
                    <div className="absolute inset-0 overflow-hidden">
                        <div className="fixed inset-y-0 right-0 flex max-w-full pl-10 sm:pl-16">
                            <TransitionChild
                                as={Fragment}
                                enter="transform transition ease-in-out duration-300"
                                enterFrom="translate-x-full"
                                enterTo="translate-x-0"
                                leave="transform transition ease-in-out duration-300"
                                leaveFrom="translate-x-0"
                                leaveTo="translate-x-full"
                            >
                                <DialogPanel className="pointer-events-auto w-screen max-w-md">
                                    <div className="flex h-full flex-col bg-card shadow-xl">
                                        {/* Header */}
                                        <div className="flex items-center justify-between border-b border-border px-6 py-4 sm:px-8">
                                            <h2 className="text-lg font-semibold text-foreground">
                                                {editServer
                                                    ? "Edit Server"
                                                    : "Add Server"}
                                            </h2>
                                            <button
                                                onClick={() => setOpen(false)}
                                                className="rounded-md p-1 text-muted-foreground transition hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                                            >
                                                <XMarkIcon className="h-5 w-5" />
                                            </button>
                                        </div>
                                        {/* Content */}
                                        <div className="flex-1 overflow-y-auto px-6 py-6 sm:px-8">
                                            <AddPCForm editServer={editServer} />
                                        </div>
                                    </div>
                                </DialogPanel>
                            </TransitionChild>
                        </div>
                    </div>
                </div>
            </Dialog>
        </Transition>
    )
}
