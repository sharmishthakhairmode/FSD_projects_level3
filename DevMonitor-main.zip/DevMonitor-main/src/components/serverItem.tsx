import {
    Dialog,
    DialogPanel,
    Transition,
    TransitionChild
} from "@headlessui/react"
import { deleteServer, recordPing, fetchUptimePercent, fetchLastSeenOnline, fetchRttSparkline, fetchSmtpSettings } from "@/lib/db"
import { notify } from "@/lib/utils"
import { PingResult, ServerPC } from "@/types/server"
import useUIStore from "@/stores/ui"
import { invoke } from "@tauri-apps/api/core"
import { openUrl } from "@tauri-apps/plugin-opener"
import { error, warn } from "@tauri-apps/plugin-log"
import { ExternalLink, Pencil, Trash2 } from "lucide-react"
import { LineChart, Line, ResponsiveContainer } from "recharts"
import { motion } from "framer-motion"
import { Fragment, useEffect, useState } from "react"

interface ServerItemsProps {
    server: ServerPC
    index: number
}

export default function ServerItem({ server, index }: ServerItemsProps) {
    const [online, setOnline] = useState(false)
    const [loading, setLoading] = useState(true)
    const [responseTime, setResponseTime] = useState<number | null>(null)
    const [confirmOpen, setConfirmOpen] = useState(false)
    const [uptime, setUptime] = useState<number | null>(null)
    const [lastSeenOnline, setLastSeenOnline] = useState<number | null>(null)
    const [sparkData, setSparkData] = useState<{ v: number }[]>([])
    const { openEditDrawer, openDetailDrawer, triggerReload, updateServerStatus, pingKey, canAlert, recordAlert } =
        useUIStore()

    useEffect(() => {
        let previousOnline = false
        const checkOnline = async () => {
            try {
                const result = await invoke<PingResult>("ping_server", {
                    domain: server.ip_domain,
                    ip: server.ip_domain,
                    protocol: server.protocol,
                    port: server.port
                })
                setOnline(result.success)
                setResponseTime(result.rtt)
                setLoading(false)
                updateServerStatus(server.serverName, result.success)
                warn(`Ping: ${server.serverName} => ${result.success}`)
                recordPing(server.serverName, result.success, result.rtt).catch(console.error)

                if (!result.success && previousOnline && canAlert(server.serverName)) {
                    recordAlert(server.serverName)
                    notify(
                        `${server.serverName} Offline`,
                        `${server.serverName} - ${server.ip_domain}`
                    )

                    // TICK-A07: Send email alert
                    fetchSmtpSettings()
                        .then((smtp) => {
                            if (smtp) {
                                invoke("send_alert_email", {
                                    host: smtp.host,
                                    port: smtp.port,
                                    user: smtp.user,
                                    password: smtp.password,
                                    from: smtp.fromAddress,
                                    to: smtp.toAddress,
                                    subject: `[DevMonitor] ${server.serverName} is DOWN`,
                                    body: `${server.serverName} (${server.ip_domain}) is unreachable as of ${new Date().toISOString()}.`
                                }).catch(console.error)
                            }
                        })
                        .catch(console.error)

                    // TICK-A11: Send webhook alert
                    if (server.webhook_url) {
                        invoke("send_webhook", {
                            url: server.webhook_url,
                            serverName: server.serverName,
                            status: "offline",
                            rtt: null,
                            timestamp: Date.now()
                        }).catch(console.error)
                    }
                }
                previousOnline = result.success
            } catch {
                error(`Ping failed: ${server.serverName}`)
                setOnline(false)
                setResponseTime(null)
                setLoading(false)
                updateServerStatus(server.serverName, false)
                recordPing(server.serverName, false, null).catch(console.error)

                if (previousOnline && canAlert(server.serverName)) {
                    recordAlert(server.serverName)
                    notify(
                        `${server.serverName} Offline`,
                        `${server.serverName} - ${server.ip_domain}`
                    )

                    // TICK-A07: Send email alert
                    fetchSmtpSettings()
                        .then((smtp) => {
                            if (smtp) {
                                invoke("send_alert_email", {
                                    host: smtp.host,
                                    port: smtp.port,
                                    user: smtp.user,
                                    password: smtp.password,
                                    from: smtp.fromAddress,
                                    to: smtp.toAddress,
                                    subject: `[DevMonitor] ${server.serverName} is DOWN`,
                                    body: `${server.serverName} (${server.ip_domain}) is unreachable as of ${new Date().toISOString()}.`
                                }).catch(console.error)
                            }
                        })
                        .catch(console.error)

                    // TICK-A11: Send webhook alert
                    if (server.webhook_url) {
                        invoke("send_webhook", {
                            url: server.webhook_url,
                            serverName: server.serverName,
                            status: "offline",
                            rtt: null,
                            timestamp: Date.now()
                        }).catch(console.error)
                    }
                }
                previousOnline = false
            }
        }

        checkOnline()
        const interval = setInterval(checkOnline, server.timeMilliseconds)
        return () => clearInterval(interval)
    }, [server, pingKey]) // pingKey re-triggers an immediate ping of all servers

    useEffect(() => {
        const load = () => {
            const since = Date.now() - 24 * 60 * 60 * 1000
            fetchUptimePercent(server.serverName, since)
                .then(setUptime)
                .catch(console.error)
        }
        load()
        const id = setInterval(load, 60_000)
        return () => clearInterval(id)
    }, [server.serverName])

    // TICK-S05: Fetch and display "offline since" time
    useEffect(() => {
        if (online || loading) return
        fetchLastSeenOnline(server.serverName)
            .then(setLastSeenOnline)
            .catch(console.error)
    }, [server.serverName, online, loading])

    // TICK-G05: Fetch sparkline data
    useEffect(() => {
        fetchRttSparkline(server.serverName, 20)
            .then((values) => setSparkData(values.map((v) => ({ v }))))
            .catch(console.error)
    }, [server.serverName, online])

    const buildUrl = () => {
        const isDefaultPort =
            (server.protocol === "https" && server.port === 443) ||
            (server.protocol === "http" && server.port === 80)
        return isDefaultPort
            ? `${server.protocol}://${server.ip_domain}`
            : `${server.protocol}://${server.ip_domain}:${server.port}`
    }

    const handleOpenUrl = async () => {
        const url = buildUrl()
        try {
            await openUrl(url)
        } catch (err) {
            console.error(`Failed to open ${url}:`, err)
            error(`Failed to open ${url}: ${String(err)}`)
        }
    }

    const handleConfirmDelete = async () => {
        await deleteServer(server.serverName)
        setConfirmOpen(false)
        triggerReload()
    }

    const protocolBadgeClass =
        server.protocol === "https"
            ? "bg-blue-500/10 text-blue-600 dark:text-blue-400"
            : "bg-orange-500/10 text-orange-600 dark:text-orange-400"

    return (
        <>
            <motion.div
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -12, height: 0 }}
                transition={{ duration: 0.18, delay: index * 0.04 }}
                className="group flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-3 shadow-sm transition-shadow duration-200 hover:shadow-md"
            >
                {/* Status dot */}
                <div
                    className={`h-2.5 w-2.5 shrink-0 rounded-full transition-all ${
                        loading
                            ? "animate-pulse bg-muted-foreground/40"
                            : online
                              ? "bg-green-500"
                              : "bg-destructive"
                    }`}
                />

                {/* Info — clicking opens detail drawer */}
                <button
                    onClick={() => openDetailDrawer(server)}
                    className="min-w-0 flex-1 text-left focus-visible:outline-none group/link"
                >
                    <div className="flex items-baseline gap-2">
                        <span className="truncate font-semibold text-foreground group-hover/link:underline underline-offset-2">
                            {server.serverName}
                        </span>
                        <span className="truncate text-xs text-muted-foreground">
                            {server.ip_domain}:{server.port}
                        </span>
                    </div>
                    {responseTime !== null && !loading && (
                        <div className="mt-0.5 text-xs text-muted-foreground">
                            {responseTime}ms
                        </div>
                    )}
                </button>

                {/* Protocol badge */}
                <span
                    className={`shrink-0 hidden sm:inline-flex items-center rounded px-1.5 py-0.5 text-xs font-medium uppercase tracking-wide ${protocolBadgeClass}`}
                >
                    {server.protocol}
                </span>

                {/* Sparkline — hidden on small screens */}
                {sparkData.length >= 2 && (
                    <div className="hidden md:block shrink-0 w-20 h-8">
                        <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={sparkData}>
                                <Line
                                    type="monotone"
                                    dataKey="v"
                                    stroke="var(--color-primary)"
                                    strokeWidth={1.5}
                                    dot={false}
                                    isAnimationActive={false}
                                />
                            </LineChart>
                        </ResponsiveContainer>
                    </div>
                )}

                {/* Uptime badge */}
                {uptime !== null && (
                    <span
                        className={`shrink-0 hidden sm:inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium ${
                            uptime >= 95
                                ? "bg-green-500/10 text-green-700 dark:text-green-400"
                                : uptime >= 80
                                  ? "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400"
                                  : "bg-destructive/10 text-destructive"
                        }`}
                    >
                        {uptime}%
                    </span>
                )}

                {/* Status badge or offline since time */}
                {!online && !loading && lastSeenOnline ? (
                    <span className="shrink-0 text-xs text-destructive">
                        offline since {new Date(lastSeenOnline).toLocaleTimeString()}
                    </span>
                ) : (
                    <span
                        className={`shrink-0 inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium transition-colors ${
                            loading
                                ? "bg-muted text-muted-foreground"
                                : online
                                  ? "bg-green-500/10 text-green-700 dark:text-green-400"
                                  : "bg-destructive/10 text-destructive"
                        }`}
                    >
                        {loading ? "…" : online ? "Online" : "Offline"}
                    </span>
                )}

                {/* Actions */}
                <div className="flex shrink-0 items-center gap-1">
                    <button
                        onClick={handleOpenUrl}
                        className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                        title="Open in browser"
                        aria-label={`Open ${server.serverName} in browser`}
                    >
                        <ExternalLink className="h-3.5 w-3.5" />
                    </button>
                    <button
                        onClick={() => openEditDrawer(server)}
                        className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                        title="Edit server"
                        aria-label={`Edit ${server.serverName}`}
                    >
                        <Pencil className="h-3.5 w-3.5" />
                    </button>
                    <button
                        onClick={() => setConfirmOpen(true)}
                        className="flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                        title="Delete server"
                        aria-label={`Delete ${server.serverName}`}
                    >
                        <Trash2 className="h-3.5 w-3.5" />
                    </button>
                </div>
            </motion.div>

            {/* Delete confirmation */}
            <Transition show={confirmOpen} as={Fragment}>
                <Dialog
                    as="div"
                    className="relative z-50"
                    onClose={() => setConfirmOpen(false)}
                >
                    <TransitionChild
                        as={Fragment}
                        enter="ease-out duration-200"
                        enterFrom="opacity-0"
                        enterTo="opacity-100"
                        leave="ease-in duration-150"
                        leaveFrom="opacity-100"
                        leaveTo="opacity-0"
                    >
                        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" />
                    </TransitionChild>

                    <div className="fixed inset-0 flex items-center justify-center p-4">
                        <TransitionChild
                            as={Fragment}
                            enter="ease-out duration-200"
                            enterFrom="opacity-0 scale-95"
                            enterTo="opacity-100 scale-100"
                            leave="ease-in duration-150"
                            leaveFrom="opacity-100 scale-100"
                            leaveTo="opacity-0 scale-95"
                        >
                            <DialogPanel className="w-full max-w-sm rounded-xl border border-border bg-card p-6 shadow-xl">
                                <div className="flex items-center gap-3">
                                    <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-destructive/10">
                                        <Trash2 className="h-4 w-4 text-destructive" />
                                    </div>
                                    <h3 className="text-base font-semibold text-foreground">
                                        Remove server?
                                    </h3>
                                </div>
                                <p className="mt-3 text-sm text-muted-foreground">
                                    <span className="font-medium text-foreground">
                                        {server.serverName}
                                    </span>{" "}
                                    ({server.ip_domain}) will be permanently
                                    removed from monitoring.
                                </p>
                                <div className="mt-5 flex gap-3">
                                    <button
                                        onClick={() => setConfirmOpen(false)}
                                        className="flex-1 rounded-md border border-border bg-background px-4 py-2 text-sm font-medium text-foreground transition hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                                    >
                                        Cancel
                                    </button>
                                    <button
                                        onClick={handleConfirmDelete}
                                        className="flex-1 rounded-md bg-destructive px-4 py-2 text-sm font-medium text-white transition hover:bg-destructive/90 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/50"
                                    >
                                        Remove
                                    </button>
                                </div>
                            </DialogPanel>
                        </TransitionChild>
                    </div>
                </Dialog>
            </Transition>
        </>
    )
}
