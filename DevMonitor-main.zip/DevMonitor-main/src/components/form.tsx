import { addServer, updateServer } from "@/lib/db"
import { ServerPC } from "@/types/server"
import useUIStore from "@/stores/ui"
import { zodResolver } from "@hookform/resolvers/zod"
import { useEffect, useState } from "react"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Checkbox } from "./catalyst/checkbox"
import { Button } from "./ui/button"
import { Form, FormControl, FormField, FormItem, FormMessage } from "./ui/form"
import { CHECK_INTERVALS } from "@/lib/constants"

const DEFAULT_PORTS = {
    http: 80,
    https: 443
} as const

const TIME_MS = Object.fromEntries(
    CHECK_INTERVALS.map((interval) => [interval.value, interval.ms])
) as Record<string, number>

const MS_TO_TIMETOCHECK = Object.fromEntries(
    CHECK_INTERVALS.map((interval) => [interval.ms, interval.value])
) as Record<number, "_30s" | "five" | "fifteen" | "thirty" | "hour">

const ProtocolEnum = z.enum(["http", "https"])
const TimeToCheckEnum = z.enum(["_30s", "five", "fifteen", "thirty", "hour"])

const formSchema = z.object({
    serverName: z
        .string()
        .min(1, { message: "Server name is required." })
        .max(30, { message: "Name must be 30 characters or less." }),
    ip_domain: z
        .string()
        .min(1, { message: "IP or domain is required." })
        .max(100),
    protocol: ProtocolEnum,
    port: z.coerce.number().int().min(1).max(65535),
    timetocheck: TimeToCheckEnum,
    notify: z.boolean(),
    alert_rtt_threshold: z.number().min(0).default(0),
    alert_after_failures: z.number().min(1).max(10).default(1),
    webhook_url: z.string().url().optional().or(z.literal("")).default("")
})

type FormInput = z.input<typeof formSchema>
type FormOutput = z.output<typeof formSchema>

interface AddPCFormProps {
    editServer?: ServerPC | null
}

const inputClass =
    "block w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground shadow-sm transition focus:border-ring focus:ring-1 focus:ring-ring focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed"

const selectClass =
    "block w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground shadow-sm transition focus:border-ring focus:ring-1 focus:ring-ring focus:outline-none"

export default function AddPCForm({ editServer }: AddPCFormProps) {
    const { triggerReload, closeDrawer } = useUIStore()
    const isEditing = !!editServer
    const [formError, setFormError] = useState<string | null>(null)

    const form = useForm<FormInput, any, FormOutput>({
        resolver: zodResolver(formSchema),
        mode: "onBlur",
        defaultValues: {
            serverName: editServer?.serverName ?? "",
            ip_domain: editServer?.ip_domain ?? "",
            protocol: (editServer?.protocol as "http" | "https") ?? "https",
            port: editServer?.port ?? DEFAULT_PORTS.https,
            timetocheck:
                MS_TO_TIMETOCHECK[editServer?.timeMilliseconds ?? 0] ??
                "thirty",
            notify: (editServer?.notify ?? 0) === 1,
            alert_rtt_threshold: editServer?.alert_rtt_threshold ?? 0,
            alert_after_failures: editServer?.alert_after_failures ?? 1,
            webhook_url: editServer?.webhook_url ?? ""
        }
    })

    // Reset when the drawer opens for a different server
    useEffect(() => {
        setFormError(null)
        form.reset({
            serverName: editServer?.serverName ?? "",
            ip_domain: editServer?.ip_domain ?? "",
            protocol: (editServer?.protocol as "http" | "https") ?? "https",
            port: editServer?.port ?? DEFAULT_PORTS.https,
            timetocheck:
                MS_TO_TIMETOCHECK[editServer?.timeMilliseconds ?? 0] ??
                "thirty",
            notify: (editServer?.notify ?? 0) === 1,
            alert_rtt_threshold: editServer?.alert_rtt_threshold ?? 0,
            alert_after_failures: editServer?.alert_after_failures ?? 1,
            webhook_url: editServer?.webhook_url ?? ""
        })
    }, [editServer, form])

    const protocol = form.watch("protocol")

    // Auto-fill port when protocol changes if user hasn't touched port
    useEffect(() => {
        const dirtyPort = (form.formState.dirtyFields as any)?.port
        if (!dirtyPort && !isEditing) {
            form.setValue(
                "port",
                DEFAULT_PORTS[protocol as keyof typeof DEFAULT_PORTS],
                { shouldDirty: false, shouldValidate: true }
            )
        }
    }, [protocol, form, isEditing])

    const onSubmit = async (values: FormOutput) => {
        setFormError(null)
        const serverData: ServerPC = {
            serverName: values.serverName,
            ip_domain: values.ip_domain,
            protocol: values.protocol,
            port: values.port,
            timeMilliseconds: TIME_MS[values.timetocheck],
            notify: values.notify ? 1 : 0,
            alert_rtt_threshold: values.alert_rtt_threshold,
            alert_after_failures: values.alert_after_failures,
            webhook_url: values.webhook_url
        }

        const action = isEditing
            ? updateServer(serverData)
            : addServer(serverData)

        await action
            .then(() => {
                triggerReload()
                closeDrawer()
            })
            .catch((err) => {
                console.error("Error saving server:", err)
                setFormError("Failed to save. Please check the details and try again.")
            })
    }

    return (
        <div className="w-full">
            <Form {...form}>
                <form
                    onSubmit={form.handleSubmit(onSubmit)}
                    className="space-y-5"
                >
                    {/* Server Name */}
                    <FormField
                        control={form.control}
                        name="serverName"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    Server Name
                                    {isEditing && (
                                        <span className="ml-2 text-xs text-muted-foreground font-normal">
                                            (cannot be changed)
                                        </span>
                                    )}
                                </label>
                                <FormControl>
                                    <input
                                        {...field}
                                        placeholder="e.g., Production API"
                                        autoComplete="off"
                                        disabled={isEditing}
                                        className={inputClass}
                                    />
                                </FormControl>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* IP / Domain */}
                    <FormField
                        control={form.control}
                        name="ip_domain"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    IP Address or Domain
                                </label>
                                <FormControl>
                                    <input
                                        {...field}
                                        placeholder="e.g., 192.168.1.1 or example.com"
                                        autoComplete="off"
                                        className={inputClass}
                                    />
                                </FormControl>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Protocol + Port side by side */}
                    <div className="grid grid-cols-2 gap-3">
                        <FormField
                            control={form.control}
                            name="protocol"
                            render={({ field }) => (
                                <FormItem>
                                    <label className="block text-sm font-medium text-foreground mb-1.5">
                                        Protocol
                                    </label>
                                    <FormControl>
                                        <select
                                            {...field}
                                            className={selectClass}
                                        >
                                            <option value="http">HTTP</option>
                                            <option value="https">HTTPS</option>
                                        </select>
                                    </FormControl>
                                    <FormMessage className="text-xs" />
                                </FormItem>
                            )}
                        />

                        <FormField
                            control={form.control}
                            name="port"
                            render={({ field }) => (
                                <FormItem>
                                    <label className="block text-sm font-medium text-foreground mb-1.5">
                                        Port
                                    </label>
                                    <FormControl>
                                        <input
                                            {...field}
                                            type="number"
                                            inputMode="numeric"
                                            min={1}
                                            max={65535}
                                            value={field.value as number}
                                            placeholder="443"
                                            className={inputClass}
                                        />
                                    </FormControl>
                                    <FormMessage className="text-xs" />
                                </FormItem>
                            )}
                        />
                    </div>

                    {/* Check Interval */}
                    <FormField
                        control={form.control}
                        name="timetocheck"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    Check Interval
                                </label>
                                <FormControl>
                                    <select
                                        value={field.value ?? "thirty"}
                                        onChange={field.onChange}
                                        onBlur={field.onBlur}
                                        name={field.name}
                                        ref={field.ref}
                                        className={selectClass}
                                    >
                                        {CHECK_INTERVALS.map((interval) => (
                                            <option key={interval.value} value={interval.value}>
                                                {interval.label}
                                            </option>
                                        ))}
                                    </select>
                                </FormControl>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Alert if RTT exceeds (ms) - TICK-A01 */}
                    <FormField
                        control={form.control}
                        name="alert_rtt_threshold"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    Alert if RTT exceeds (ms)
                                </label>
                                <FormControl>
                                    <input
                                        {...field}
                                        type="number"
                                        min={0}
                                        step={10}
                                        placeholder="0 — disabled"
                                        className={inputClass}
                                    />
                                </FormControl>
                                <p className="mt-1 text-xs text-muted-foreground">Set to 0 to disable RTT alerts.</p>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Alert after N failures - TICK-A02 */}
                    <FormField
                        control={form.control}
                        name="alert_after_failures"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    Alert after N failures
                                </label>
                                <FormControl>
                                    <input
                                        {...field}
                                        type="number"
                                        min={1}
                                        max={10}
                                        placeholder="1"
                                        className={inputClass}
                                    />
                                </FormControl>
                                <p className="mt-1 text-xs text-muted-foreground">Number of consecutive failures before alerting.</p>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Webhook URL - TICK-A09 */}
                    <FormField
                        control={form.control}
                        name="webhook_url"
                        render={({ field }) => (
                            <FormItem>
                                <label className="block text-sm font-medium text-foreground mb-1.5">
                                    Webhook URL
                                </label>
                                <FormControl>
                                    <input
                                        {...field}
                                        type="text"
                                        placeholder="https://hooks.example.com/..."
                                        className={inputClass}
                                    />
                                </FormControl>
                                <p className="mt-1 text-xs text-muted-foreground">Leave blank to disable. Receives a POST when the server goes offline.</p>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Notify toggle */}
                    <FormField
                        control={form.control}
                        name="notify"
                        render={({ field }) => (
                            <FormItem className="flex items-center gap-3 pt-1">
                                <FormControl>
                                    <Checkbox
                                        id="notify"
                                        checked={field.value as boolean}
                                        onChange={field.onChange}
                                    />
                                </FormControl>
                                <label
                                    htmlFor="notify"
                                    className="cursor-pointer text-sm font-medium text-foreground select-none"
                                >
                                    Notify when offline
                                </label>
                                <FormMessage className="text-xs" />
                            </FormItem>
                        )}
                    />

                    {/* Form-level error */}
                    {formError && (
                        <p className="rounded-md border border-destructive/20 bg-destructive/5 px-3 py-2 text-xs text-destructive">
                            {formError}
                        </p>
                    )}

                    {/* Submit */}
                    <div className="pt-2">
                        <Button type="submit" className="w-full">
                            {isEditing ? "Save Changes" : "Add Server"}
                        </Button>
                    </div>
                </form>
            </Form>
        </div>
    )
}
