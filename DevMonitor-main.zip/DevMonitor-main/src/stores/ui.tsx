import { ServerPC } from "@/types/server"
import { create } from "zustand"

interface UIStore {
    // Drawer
    drawerOpen: boolean
    editServer: ServerPC | null
    openAddDrawer: () => void
    openEditDrawer: (server: ServerPC) => void
    closeDrawer: () => void

    // Detail drawer
    detailServer: ServerPC | null
    openDetailDrawer: (server: ServerPC) => void
    closeDetailDrawer: () => void

    // List refresh (re-fetches from DB)
    reloadKey: number
    triggerReload: () => void

    // Ping refresh (re-pings all server items immediately)
    pingKey: number
    triggerPing: () => void

    // Per-server online status, populated by ServerItem as pings complete
    serverStatuses: Record<string, boolean | null>
    totalServers: number
    updateServerStatus: (name: string, online: boolean | null) => void
    setTotalServers: (n: number) => void
    clearServerStatuses: () => void

    // Theme
    isDark: boolean
    toggleTheme: () => void

    // TICK-A03: Alert cooldown
    lastAlertTime: Record<string, number>
    canAlert: (serverName: string, cooldownMs?: number) => boolean
    recordAlert: (serverName: string) => void

    // TICK-A05: Settings drawer
    settingsOpen: boolean
    openSettings: () => void
    closeSettings: () => void
}

function getInitialDark(): boolean {
    try {
        const saved = localStorage.getItem("devmonitor-theme")
        if (saved === "dark") return true
        if (saved === "light") return false
    } catch {}
    return window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false
}

function applyTheme(dark: boolean) {
    document.documentElement.classList.toggle("dark", dark)
    try {
        localStorage.setItem("devmonitor-theme", dark ? "dark" : "light")
    } catch {}
}

const useUIStore = create<UIStore>((set, get) => {
    const isDark = getInitialDark()
    applyTheme(isDark)

    return {
        drawerOpen: false,
        editServer: null,
        openAddDrawer: () => set({ drawerOpen: true, editServer: null }),
        openEditDrawer: (server: ServerPC) =>
            set({ drawerOpen: true, editServer: server }),
        closeDrawer: () => set({ drawerOpen: false, editServer: null }),

        detailServer: null,
        openDetailDrawer: (server: ServerPC) => set({ detailServer: server }),
        closeDetailDrawer: () => set({ detailServer: null }),

        reloadKey: 0,
        triggerReload: () =>
            set((state) => ({ reloadKey: state.reloadKey + 1 })),

        pingKey: 0,
        triggerPing: () =>
            set((state) => ({ pingKey: state.pingKey + 1 })),

        serverStatuses: {},
        totalServers: 0,
        updateServerStatus: (name, online) =>
            set((state) => ({
                serverStatuses: { ...state.serverStatuses, [name]: online }
            })),
        setTotalServers: (n) => set({ totalServers: n }),
        clearServerStatuses: () => set({ serverStatuses: {} }),

        isDark,
        toggleTheme: () =>
            set((state) => {
                const next = !state.isDark
                applyTheme(next)
                return { isDark: next }
            }),

        // TICK-A03: Alert cooldown
        lastAlertTime: {},
        canAlert: (serverName, cooldownMs = 5 * 60 * 1000) => {
            const last = get().lastAlertTime[serverName] ?? 0
            return Date.now() - last > cooldownMs
        },
        recordAlert: (serverName) =>
            set((state) => ({
                lastAlertTime: {
                    ...state.lastAlertTime,
                    [serverName]: Date.now(),
                },
            })),

        // TICK-A05: Settings drawer
        settingsOpen: false,
        openSettings: () => set({ settingsOpen: true }),
        closeSettings: () => set({ settingsOpen: false }),
    }
})

export default useUIStore
