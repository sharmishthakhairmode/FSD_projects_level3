// Learn more about Tauri commands at https://tauri.app/develop/calling-rust/
pub mod db_migration;

use futures::future::join_all;
use httping::{ping, ping_with_metrics};
use log;
use serde::{Deserialize, Serialize};
use std::net::Ipv4Addr;

static ONLINE_SERVERS: [&str; 3] = ["www.google.com", "one.one.one.one", "www.amazon.com"];
static DB_URL: &str = "sqlite:data.db";

#[tauri::command]
async fn check_online() -> bool {
    let futures = ONLINE_SERVERS
        .iter()
        .map(|&server| async move { ping(server, "", "https", 443).await.is_ok() });

    join_all(futures).await.into_iter().any(|b| b)
}

#[derive(Serialize)]
struct PingResult {
    server_name: String,
    success: bool,
    rtt: u64,
}

#[tauri::command]
async fn ping_server(domain: &str, protocol: &str, port: u32) -> Result<PingResult, String> {
    let mut ip = "".to_string();
    let mut server_domain = domain.to_string();

    if domain.parse::<Ipv4Addr>().is_ok() {
        ip = server_domain.clone();
        server_domain = "".to_string();
    }
    match ping_with_metrics(&server_domain, &ip, protocol, port).await {
        Ok(v) => Ok(PingResult {
            server_name: domain.to_string(),
            success: v.success,
            rtt: v.rtt as u64,
        }),
        Err(e) => Err(e.to_string()),
    }
}

// TICK-A06: Send alert email via SMTP
#[derive(Deserialize)]
struct EmailParams {
    host: String,
    port: u16,
    user: String,
    password: String,
    from: String,
    to: String,
    subject: String,
    body: String,
}

#[tauri::command]
async fn send_alert_email(params: EmailParams) -> Result<(), String> {
    use lettre::{
        transport::smtp::authentication::Credentials,
        AsyncSmtpTransport, AsyncTransport, Message, Tokio1Executor,
    };

    let email = Message::builder()
        .from(
            params
                .from
                .parse()
                .map_err(|e: lettre::address::AddressError| e.to_string())?,
        )
        .to(
            params
                .to
                .parse()
                .map_err(|e: lettre::address::AddressError| e.to_string())?,
        )
        .subject(&params.subject)
        .body(params.body)
        .map_err(|e| e.to_string())?;

    let creds = Credentials::new(params.user, params.password);

    let transport = AsyncSmtpTransport::<Tokio1Executor>::relay(&params.host)
        .map_err(|e| e.to_string())?
        .port(params.port)
        .credentials(creds)
        .build();

    transport.send(email).await.map_err(|e| e.to_string())?;

    Ok(())
}

// TICK-A10: Send webhook POST
#[tauri::command]
async fn send_webhook(
    url: String,
    server_name: String,
    status: String,
    rtt: Option<u64>,
    timestamp: u64,
) -> Result<(), String> {
    #[derive(Serialize)]
    struct WebhookPayload {
        server_name: String,
        status: String,
        rtt: Option<u64>,
        timestamp: u64,
    }

    let payload = WebhookPayload {
        server_name,
        status,
        rtt,
        timestamp,
    };

    reqwest::Client::new()
        .post(&url)
        .json(&payload)
        .send()
        .await
        .map_err(|e| e.to_string())?;

    Ok(())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_notification::init())
        .plugin(
            tauri_plugin_log::Builder::new()
                .level(log::LevelFilter::Info)
                .build(),
        )
        .plugin(
            tauri_plugin_sql::Builder::new()
                .add_migrations(DB_URL, db_migration::create_initial_tables())
                .build(),
        )
        .plugin(tauri_plugin_opener::init())
        // Combine commands in ONE handler:
        .invoke_handler(tauri::generate_handler![check_online, ping_server, send_alert_email, send_webhook])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
