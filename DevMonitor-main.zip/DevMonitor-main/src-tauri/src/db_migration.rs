use tauri_plugin_sql::{Migration, MigrationKind};

pub fn create_initial_tables() -> Vec<Migration> {
    println!("===> Apply DB Migration");
    let migrations = vec![
        // Define your migrations here
        Migration {
            version: 1,
            description: "create_initial_tables",
            sql: "CREATE TABLE servers (
                id INTEGER PRIMARY KEY,
                serverName TEXT,
                ip_domain TEXT,
                protocol TEXT,
                port INTEGER,
                timeMilliseconds INTEGER,
                notify INTEGER
            );",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 2,
            description: "create_ping_history",
            sql: "CREATE TABLE ping_history (
                id          INTEGER PRIMARY KEY,
                serverName  TEXT    NOT NULL,
                timestamp   INTEGER NOT NULL,
                success     INTEGER NOT NULL,
                rtt         INTEGER
            );",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 3,
            description: "create_ping_history_index",
            sql: "CREATE INDEX idx_ping_history_server_time
                  ON ping_history (serverName, timestamp DESC);",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 4,
            description: "add_rtt_threshold",
            sql: "ALTER TABLE servers ADD COLUMN alert_rtt_threshold INTEGER NOT NULL DEFAULT 0;",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 5,
            description: "add_alert_after_failures",
            sql: "ALTER TABLE servers ADD COLUMN alert_after_failures INTEGER NOT NULL DEFAULT 1;",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 6,
            description: "create_settings_table",
            sql: "CREATE TABLE settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );",
            kind: MigrationKind::Up,
        },
        Migration {
            version: 7,
            description: "add_webhook_url",
            sql: "ALTER TABLE servers ADD COLUMN webhook_url TEXT NOT NULL DEFAULT '';",
            kind: MigrationKind::Up,
        },
    ];
    println!("===> DONE!");
    migrations
}
